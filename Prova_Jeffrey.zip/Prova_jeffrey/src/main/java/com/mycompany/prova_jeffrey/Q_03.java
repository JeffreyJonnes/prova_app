/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_jeffrey;

import java.util.Scanner;

/**
 *
 * @author jsantos
 */
public class Q_03 {
        public static void main(String[] args) {
            Scanner numero = new Scanner (System.in);
            System.out.print("Digite um numero inteiro: ");
            int n1 = numero.nextInt();
            System.out.println("O numero digitado foi: " +n1);
            System.out.println("O seu antecessor é: " + --n1);
            
    }
}
