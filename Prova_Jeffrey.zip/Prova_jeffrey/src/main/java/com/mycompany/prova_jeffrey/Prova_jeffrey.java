/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prova_jeffrey;

/**
 *
 * @author jsantos
 */
public class Prova_jeffrey {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
