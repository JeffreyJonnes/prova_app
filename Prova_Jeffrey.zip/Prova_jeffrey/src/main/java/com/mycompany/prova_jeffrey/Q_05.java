/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_jeffrey;

import java.util.Scanner;

/**
 *
 * @author jsantos
 */
public class Q_05 {
       public static void main(String[] args) {
           Scanner numero = new Scanner(System.in);
           System.out.print("Digite um numero: ");
           float n1 = numero.nextFloat();
           System.out.print("Digite um numero: ");
           float n2 = numero.nextFloat();
           System.out.print("Digite um numero: ");
           float n3 = numero.nextFloat();
           
           System.out.print("A media dos nomeros digitados: " + (n1+n2+n3)/3 + "\n");
           System.out.print("A Soma dos nomeros digitados é: " +(n1+n2+n3));
                
    }
}
