/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_jeffrey;

import java.util.Scanner;

/**
 *
 * @author jsantos
 */
public class Q_18 {
       public static void main(String[] args) {
        Scanner valor = new Scanner(System.in);
           System.out.print("Quanto você ganha por hora: ");
           float valor_hora = valor.nextFloat();
           System.out.print("Quantas hora por mês: ");
           int horas = valor.nextInt();
           float salario_bruto = (horas * valor_hora);
           System.out.format("+ Salario bruto é R$:%,.2f: \n", salario_bruto);
           float inss =(( salario_bruto*8)/100);       
           System.out.format("- INSS  R$:%,.2f \n", inss);
           float ir =(( salario_bruto*11)/100);       
           System.out.format("- IR  R$:%,.2f \n", ir);
           float sindicato =(( salario_bruto*5)/100);       
           System.out.format("- Sindicato  R$:%,.2f \n", sindicato);
           float salario_liquido = salario_bruto - inss - ir - sindicato;
           System.out.format("= Salario liquido é R$:%,.2f: ", salario_liquido);
           
           
           
           
    }
    
}
